create function gettimestamp() returns timestamp without time zone
    language plpgsql
as
$$
BEGIN
	RETURN CURRENT_TIMESTAMP;
END; $$;

alter function gettimestamp() owner to s408301;

